package com.example.busstand_tracker;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class BusTimings extends AppCompatActivity {
    ListView listView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bus_timings);
        listView = (ListView) findViewById(R.id.lst);
        String[] routes = new String[] { "Kottayam -Kumaly",
                "Kottayam -Ranny",
                "Kumaly- Kottayam",
                "Kumaly-Changanassery",
                "Changanassery- Kumaly",
                "Pala-Kottayam",
                "Kottayam-Pala",
                "Erumely-Kottayam"
        };
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,routes);
        listView.setAdapter(adapter);



        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
              String[]urls=new String[] {"https://www.aanavandi.com/search/results/source/kottayam-bs-(ktm)/destination/kumali/type/2/timing/all","https://www.aanavandi.com/search/results/source/kottayam-bs-(ktm)/destination/ranny-(rni)/type/2/timing/all","https://www.aanavandi.com/search/results/source/mundakayam/destination/kottayam-bs-(ktm)/type/2/timing/all","https://www.aanavandi.com/search/results/source/mundakayam/destination/changanassery-bs-(chr)/type/2/timing/all","https://www.aanavandi.com/search/results/source/changanassery-bs-(chr)/destination/kumali/type/2/timing/all","https://www.aanavandi.com/search/results/source/pala-(pla)/destination/kottayam-bs-(ktm)/type/1/timing/all","https://www.aanavandi.com/search/results/source/kottayam-bs-(ktm)/destination/pala-(pla)/type/1/timing/all","https://www.aanavandi.com/search/results/source/erumely-(emy)/destination/kottayam-bs-(ktm)/type/1/timing/all"};
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(urls[position]));
                Intent browserChooserIntent = Intent.createChooser(browserIntent , "Choose browser of your choice");
                startActivity(browserChooserIntent );

            }
        });
    }
}
