package com.example.busstand_tracker;

import android.content.Context;
import android.content.Intent;
import android.database.DataSetObserver;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class Enquiry extends AppCompatActivity {
    ListView list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enquiry);
        this.getSupportActionBar().hide();
        list = findViewById(R.id.list);
        ArrayList<SubjectData> arrayList = new ArrayList<SubjectData>();
        arrayList.add(new SubjectData("Kottaym Private Bus Stand", "Nagampadam, Kottayam, Kerala 686002","https://fottam.com/wp-content/uploads/2012/11/Kottayam-Private-Bus-Stand.jpg"));
        arrayList.add(new SubjectData("Kottaym  KSRTC Bus Stand", " TB Road, Kottayam, Kerala 686001","https://i.ytimg.com/vi/TEoGPMVNjOo/mqdefault.jpg"));
        arrayList.add(new SubjectData("Changanassery Bus Stand", " Changanassery - Vazhoor Rd, Changanassery, Kerala 686101","https://upload.wikimedia.org/wikipedia/commons/thumb/1/16/Karukachalbusstand_02.jpg/1200px-Karukachalbusstand_02.jpg"));
        arrayList.add(new SubjectData("Karukachal Bus Stand", " Main Street,, Karukachal, Kerala","https://mw2.google.com/mw-panoramio/photos/medium/65023930.jpg"));
        arrayList.add(new SubjectData("Pampady Private Bus Stand", " Kollam -Theni Hwy, Pampady, Kerala 686502","https://i.ytimg.com/vi/ADgEgxpucZ0/hqdefault.jpg"));
        arrayList.add(new SubjectData("Ponkunnam Bus Station", "  Post Office Rd, Ponkunnam, Kerala 686506","https://live.staticflickr.com/4052/4646243890_f31253d645_b.jpg"));
        arrayList.add(new SubjectData("Kanjirappally Bus Stand", "  Bus stand to Pulpel, Puthanangady Rd, Kanjirappally, Kerala 686507","https://content3.jdmagicbox.com/comp/kottayam/h6/9999px481.x481.170925081423.t2h6/catalogue/kanjirappally-bus-stand-kanjirapally-kottayam-bus-services-0qbp9mvkv5-250.jpg"));
        arrayList.add(new SubjectData("Manimala  Bus Station", "   Karukachal Manimala Rd, Erathuvadakara, Manimala, Kerala 686543","https://img-mm.manoramaonline.com/content/dam/mm/ch/kottayam/local-news/images/2017/10/25/kottayam-manimala-busstand.jpg.image.784.410.jpg"));
        arrayList.add(new SubjectData("Pala Kottaramattam Bus Stand", "Pala - Marangattupilly - Kozha Road, [no name], Vellappadu, Pala, Kerala 686575","http://mw2.google.com/mw-panoramio/photos/medium/44433129.jpg"));



        CustomAdapter customAdapter = new CustomAdapter(this, arrayList);
        list.setAdapter(customAdapter);





    }


    class CustomAdapter implements ListAdapter
    {
        ArrayList<SubjectData> arrayList;
        Context context;
        public CustomAdapter(Context context, ArrayList<SubjectData> arrayList)
        {
            this.arrayList=arrayList;
            this.context=context;
        }
        @Override
        public boolean areAllItemsEnabled()
        {
            return false;
        }
        @Override
        public boolean isEnabled(int position)
        {
            return true;
        }
        @Override
        public void registerDataSetObserver(DataSetObserver observer)
        {
        }
        @Override
        public void unregisterDataSetObserver(DataSetObserver observer)
        {
        }
        @Override
        public int getCount() {
            return arrayList.size();
        }
        @Override
        public Object getItem(int position) {
            return position;
        }
        @Override
        public long getItemId(int position) {
            return position;
        }
        @Override
        public boolean hasStableIds() {
            return false;
        }
        @Override
        public View getView(int position, View convertView, ViewGroup parent)
        {
            SubjectData subjectData=arrayList.get(position);
            if(convertView==null) {
                LayoutInflater layoutInflater = LayoutInflater.from(context);
                convertView=layoutInflater.inflate(R.layout.raw, null);
                convertView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                    }
                });
                TextView title=convertView.findViewById(R.id.BTitle);
                TextView dsptn=convertView.findViewById(R.id.Bdsptn);

                ImageView imag=convertView.findViewById(R.id.imgview);
                title.setText(subjectData.SubjectName);
                dsptn.setText(subjectData.Link);
                Picasso.with(context)
                        .load(subjectData.Image)
                        .into(imag);
            }
            return convertView;
        }
        @Override
        public int getItemViewType(int position) {
            return position;
        }
        @Override
        public int getViewTypeCount() {
            return arrayList.size();
        }
        @Override
        public boolean isEmpty() {
            return false;
        }
    }
    class SubjectData {
        String SubjectName;
        String Link;
        String Image;
        public SubjectData(String subjectName, String link, String image) {
            this.SubjectName = subjectName;
            this.Link = link;
            this.Image = image;
        }
    }
}
