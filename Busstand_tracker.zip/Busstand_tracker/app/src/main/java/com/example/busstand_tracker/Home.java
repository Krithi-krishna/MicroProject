package com.example.busstand_tracker;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.Switch;

public class Home extends AppCompatActivity implements View.OnClickListener
{
    CardView track,enquiry,bustimes,contact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.getSupportActionBar().hide();
        setContentView(R.layout.activity_home);
        //define
        track=(CardView) findViewById(R.id.crd_track);
        enquiry=(CardView) findViewById(R.id.crd_enq);
        bustimes=(CardView) findViewById(R.id.crd_timing);
        contact=(CardView) findViewById(R.id.crd_contact);
        //set click listener
        track.setOnClickListener(this);
        enquiry.setOnClickListener(this);
        bustimes.setOnClickListener(this);
        contact.setOnClickListener(this);
    }

    @Override
    public void onClick(View v)
    {
        Intent i;
        switch (v.getId())
        {
            case R.id.crd_track :
                i = new Intent(Home.this,TrackerActivity.class);
                startActivity(i);
                break;

            case R.id.crd_enq:
                i = new Intent(Home.this,Enquiry.class);
                startActivity(i);
                break;
            case R.id.crd_timing:
                i = new Intent(Home.this,BusTimings.class);
                startActivity(i);
                break;
            case R.id.crd_contact:
                i = new Intent(Home.this,Contact.class);
                startActivity(i);
                break;
        }
    }
}
