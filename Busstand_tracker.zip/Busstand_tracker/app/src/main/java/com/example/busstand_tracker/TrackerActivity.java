package com.example.busstand_tracker;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class TrackerActivity extends FragmentActivity implements OnMapReadyCallback
{

    private GoogleMap mMap;
    LocationManager locationManager;
    private Circle mCircle;
    Marker marker;
    double currlat,currlong;
    LatLng selected;
    Button track;
    boolean alreadyExecuted=false;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tracker);
         track=findViewById(R.id.btn_track);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            return;
        }
        if(locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER))//if network is on this code works
        {
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, new LocationListener()
            {
                @Override
                public void onLocationChanged(Location location)
                {
                    //get the latitude
                    double latitude=location.getLatitude();

                    //get the longitude
                    double longitude=location.getLongitude();
                    //instantiate latitude longitude class to get latitude and longitude
                    LatLng latLng=new LatLng(latitude,longitude);



                          handleNewLocation(latLng);
                          track.setOnClickListener(new View.OnClickListener() {
                              @Override
                              public void onClick(View v)
                              {

                                  initmarker(9.585600,76.523191);
                                  initmarker(9.590567,76.521460);
                                  initmarker(9.596054,76.527866);
                                  initmarker(9.569756,76.640274);
                                  initmarker(9.564874,76.755832);
                                  initmarker(9.558023,76.791626);
                                  initmarker(9.538576,76.885792);
                                  initmarker(9.710971,76.680754);
                                  initmarker(9.708902,76.672945);
                                  initmarker(9.602045,76.682843);
                                  initmarker(9.503022,76.641372);
                                  initmarker(9.443492,76.544172);
                                  initmarker(9.446789,76.542272);
                                  initmarker(9.493806,76.749017);
                                  initmarker(9.386519,76.785936);
                                  initmarker(9.378028,76.779235);

                              }
                          });




                }

                @Override
                public void onStatusChanged(String provider, int status, Bundle extras) {

                }

                @Override
                public void onProviderEnabled(String provider) {

                }

                @Override
                public void onProviderDisabled(String provider) {

                }
            });

        }
        else if(locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER))//if only gps is available
        {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, new LocationListener() {
                @Override
                public void onLocationChanged(Location location)
                {
                    //get the latitude
                    double latitude=location.getLatitude();
                    //get the longitude
                    double longitude=location.getLongitude();
                    //instantiate latitude longitude class to get latitude and longitude
                    LatLng latLng=new LatLng(latitude,longitude);
                    //instantiate geocoder class,this class converts location coordinates to address
                    Geocoder geocoder=new Geocoder(getApplicationContext());

//                        List<Address>addressList=geocoder.getFromLocation(latitude,longitude,1);//get address list of location specified by latitude and longitude,maximum 1 address
                        handleNewLocation(latLng);




                }

                @Override
                public void onStatusChanged(String provider, int status, Bundle extras) {

                }

                @Override
                public void onProviderEnabled(String provider) {

                }

                @Override
                public void onProviderDisabled(String provider) {

                }
            });

        }

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.getUiSettings().setScrollGesturesEnabled(true);
        mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker)
            {
                Toast.makeText(getApplicationContext(),"Selected",Toast.LENGTH_SHORT).show();
                selected=marker.getPosition();
                Uri.Builder directionsBuilder = new Uri.Builder()
                        .scheme("https")
                        .authority("www.google.com")
                        .appendPath("maps")
                        .appendPath("dir")
                        .appendPath("")
                        .appendQueryParameter("api", "1")
                        .appendQueryParameter("destination", marker.getPosition().latitude + "," +marker.getPosition().longitude);
                startActivity(new Intent(Intent.ACTION_VIEW, directionsBuilder.build()));

                return false;
            }
        });

    }

    public void initmarker(double x,double y)
    {
    float calcdistance;
    calcdistance=distance(currlat,currlong,x,y);
    if(calcdistance<=10000.0)
    {
        LatLng ln=new LatLng(x,y);
        Geocoder geocoder=new Geocoder(getApplicationContext());
        try {
            List<Address>addressList=geocoder.getFromLocation(x,y,1);
            String locality=addressList.get(0).getLocality()+"  "+"Bus Stand";
            marker = mMap.addMarker(new MarkerOptions().position(ln).title(locality));

        }
        catch (IOException e) {
            e.printStackTrace();
        }



    }



    }

    private void handleNewLocation(LatLng latLng)
    {

        if(!alreadyExecuted)
        {
            marker=mMap.addMarker(new MarkerOptions().position(latLng).title("I am here!"));
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng,10.5f));
            mCircle = mMap.addCircle(new CircleOptions()
                    .center(latLng)
                    .radius(150)
                    .strokeColor(Color.BLUE)
                    .fillColor(Color.GREEN)
                    .strokeWidth(10));
          currlat=latLng.latitude;
          currlong=latLng.longitude;
          alreadyExecuted=true;
        }

    }



    public float distance (double lat_a, double lng_a, double lat_b, double lng_b )
    {
        double earthRadius = 3958.75;
        double latDiff = Math.toRadians(lat_b-lat_a);
        double lngDiff = Math.toRadians(lng_b-lng_a);
        double a = Math.sin(latDiff /2) * Math.sin(latDiff /2) +
                Math.cos(Math.toRadians(lat_a)) * Math.cos(Math.toRadians(lat_b)) *
                        Math.sin(lngDiff /2) * Math.sin(lngDiff /2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        double distance = earthRadius * c;

        int meterConversion = 1609;

        return new Float(distance * meterConversion).floatValue();
    }
}
