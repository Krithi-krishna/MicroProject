package com.example.busstand_tracker;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class login extends AppCompatActivity {
    EditText logemail,logpassword;
    Button btn_login;
    TextView sredirect;
    SQLiteDatabase mydb;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        this.getSupportActionBar().hide();
        logemail=(EditText)findViewById(R.id.lemail);
        logpassword=(EditText)findViewById(R.id.lpassword);
        btn_login=(Button)findViewById(R.id.Btn_login);
        sredirect=(TextView)findViewById(R.id.Gsignup);
        mydb = openOrCreateDatabase("BusTrackerDb", Context.MODE_PRIVATE, null);
        if (mydb != null)
        {
            Toast.makeText(this, "Created/Opened", Toast.LENGTH_SHORT).show();
        }
        mydb.execSQL("CREATE TABLE IF NOT EXISTS tbllogin(fname VARCHAR,email VARCHAR,phone VARCHAR,password VARCHAR);");

        btn_login.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                String email = logemail.getText().toString();
                String pass = logpassword.getText().toString();
                boolean valid=true;
                if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches())
                {
                    logemail.setError("Enter a valid email address");
                    valid = false;
                }
                else
                {
                    logemail.setError(null);
                }
                if (pass.isEmpty() || logpassword.length() < 4 || logpassword.length() > 10)
                {
                    logpassword.setError("Password Should be 4 and 10 alphanumeric characters");
                    valid = false;
                }
                else
                {
                    logpassword.setError(null);
                }

                Cursor c = mydb.rawQuery("SELECT * FROM tbllogin WHERE email='"+logemail.getText()+"' and password='"+logpassword.getText()+"'", null);
                if (c.getCount() == 0)
                {
                    showMessage("Error", "Invalid Login!");
                    clearText();
                    return;
                }
                else
                {
                    showMessage("Success", "Login Success !");
                    clearText();
                    Intent in=new Intent(login.this,Home.class);
                    startActivity(in);
                    return;
                }

            }
        });
        sredirect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent in=new Intent(login.this,signup.class);
                startActivity(in);

            }
        });
    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
    public void clearText() {

        logemail.setText("");
        logpassword.setText("");
        logemail.requestFocus();
    }
}
